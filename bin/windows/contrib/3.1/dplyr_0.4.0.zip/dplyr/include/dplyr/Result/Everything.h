#ifndef dplyr_Result_Everything_H
#define dplyr_Result_Everything_H

namespace dplyr{
    struct Everything{} ;
}
#endif
